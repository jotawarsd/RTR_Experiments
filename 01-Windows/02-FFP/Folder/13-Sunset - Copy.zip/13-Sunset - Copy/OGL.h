#pragma once

#define MYICON 69
#define IDBITMAP_STARS 420
#define IDBITMAP_PLAIN 42069
